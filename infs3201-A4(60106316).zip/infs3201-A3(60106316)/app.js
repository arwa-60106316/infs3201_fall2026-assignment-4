import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { engine } from 'express-handlebars';
import * as business from './business.js';

const app = express();
const projectDirectory = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT) || 3000;
const SESSION_COOKIE = process.env.SESSION_COOKIE_NAME || 'sessionToken';

app.engine('hbs', engine({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(projectDirectory, 'views/layouts'),
  helpers: {
    money: (value) => {
      const amount = Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
      return Number.isInteger(amount) ? String(amount) : amount.toFixed(2);
    },
    eq: (left, right) => left === right,
    lowercase: (value) => String(value || '').toLowerCase()
  }
}));
app.set('view engine', 'hbs');
app.set('views', path.join(projectDirectory, 'views'));
app.use(express.urlencoded({ extended: false }));
// Static files are registered before the session middleware so that CSS requests do not touch sessions.
app.use(express.static(path.join(projectDirectory, 'public')));

/**
 * Reads one cookie value from the request.
 * @param {import('express').Request} req the request
 * @param {string} name cookie name
 * @returns {string|null} the cookie value, or null if absent
 */
function readCookie(req, name) {
  const header = req.headers.cookie;
  if (typeof header !== 'string') return null;
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator === -1) continue;
    if (part.slice(0, separator).trim() === name) {
      try {
        return decodeURIComponent(part.slice(separator + 1).trim());
      } catch {
        return null;
      }
    }
  }
  return null;
}

/**
 * Sends the session cookie. The cookie expires at the same moment as the session
 * so that, with the sliding window, the browser cookie is renewed on each request.
 * @param {import('express').Response} res the response
 * @param {string} token the session token
 * @param {Date} expiresAt when the session ends
 * @returns {void}
 */
function sendSessionCookie(res, token, expiresAt) {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    expires: expiresAt
  });
}

/**
 * Gets the page a user lands on after logging in.
 * @param {string} userType 'staff' or 'customer'
 * @returns {string} the dashboard URL
 */
function homePathFor(userType) {
  return userType === 'staff' ? '/staff-dashboard' : '/customer-dashboard';
}

/**
 * Session middleware: loads the session named by the cookie (extending it),
 * and exposes the user type to the views so the layout can pick the right menu.
 */
app.use(async (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  req.session = null;
  req.sessionToken = null;
  res.locals.isStaff = false;
  res.locals.isCustomer = false;

  try {
    const token = readCookie(req, SESSION_COOKIE);
    if (token) {
      const session = await business.getSession(token);
      if (session) {
        req.session = session;
        req.sessionToken = token;
        res.locals.isStaff = session.userType === 'staff';
        res.locals.isCustomer = session.userType === 'customer';
        sendSessionCookie(res, token, session.expiresAt);
      } else {
        res.clearCookie(SESSION_COOKIE, { path: '/' });
      }
    }
    next();
  } catch (error) {
    next(error);
  }
});

/**
 * Authorization middleware factory.
 * Visitors who are not logged in are sent to the login page; logged in users of
 * the wrong type receive a 403 page.
 * @param {string} [userType] 'staff' or 'customer'; omit to allow any logged in user
 * @returns {import('express').RequestHandler} the middleware
 */
function requireUser(userType) {
  return (req, res, next) => {
    if (!req.session) return res.redirect('/login');
    if (userType && req.session.userType !== userType) {
      return res.status(403).render('message', {
        title: 'Access Denied',
        message: 'You do not have permission to view this page.'
      });
    }
    return next();
  };
}

app.get('/', (req, res) => {
  if (req.session) return res.redirect(homePathFor(req.session.userType));
  return res.redirect('/login');
});

app.get('/login', (req, res) => {
  if (req.session) return res.redirect(homePathFor(req.session.userType));
  return res.render('login', { title: 'Login' });
});

app.post('/login', async (req, res, next) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';

  try {
    const session = await business.login(email, password);
    if (!session) {
      return res.status(401).render('login', {
        title: 'Login',
        email,
        error: 'Invalid email or password.'
      });
    }
    // A fresh token is issued on every login; drop any session this browser had before.
    if (req.sessionToken) await business.logout(req.sessionToken);
    sendSessionCookie(res, session.token, session.expiresAt);
    return res.redirect(homePathFor(session.userType));
  } catch (error) {
    return next(error);
  }
});

app.get('/logout', async (req, res, next) => {
  try {
    if (req.sessionToken) await business.logout(req.sessionToken);
    res.clearCookie(SESSION_COOKIE, { path: '/' });
    res.redirect('/login');
  } catch (error) {
    next(error);
  }
});

// Shows who is logged in and when the session ends (handy for checking the sliding window).
app.get('/session-info', requireUser(), (req, res) => {
  res.render('session-info', {
    title: 'Session Information',
    userType: req.session.userType,
    email: req.session.email,
    expiresAt: req.session.expiresAt.toLocaleTimeString()
  });
});

app.get('/services', requireUser(), async (req, res, next) => {
  try {
    const services = await business.getServices();
    res.render('services', { title: 'Laundry Services', services });
  } catch (error) {
    next(error);
  }
});

app.get('/customer-dashboard', requireUser('customer'), async (req, res, next) => {
  try {
    const orders = await business.getOrdersForCustomer(req.session.userId);
    res.render('customer-dashboard', { title: 'Your Orders', orders });
  } catch (error) {
    next(error);
  }
});

app.get('/staff-dashboard', requireUser('staff'), async (req, res, next) => {
  try {
    const orders = await business.getOrders();
    res.render('staff-dashboard', { title: 'All Orders', orders });
  } catch (error) {
    next(error);
  }
});

// Older bookmark from the previous assignment.
app.get('/orders', requireUser('staff'), (req, res) => {
  res.redirect('/staff-dashboard');
});

app.get('/customer', requireUser('staff'), (req, res) => {
  res.render('customer-search', { title: 'Find Customer' });
});

app.get('/find-results', requireUser('staff'), async (req, res, next) => {
  const phone = typeof req.query.customer_number === 'string' ? req.query.customer_number.trim() : '';
  if (!phone) {
    return res.status(400).render('find-results', {
      title: 'Customer Search Results',
      error: 'Enter a customer phone number to search.'
    });
  }

  try {
    const customer = await business.getCustomerInformationByPhone(phone);
    if (!customer) {
      return res.status(404).render('find-results', {
        title: 'Customer Search Results',
        error: `No customer was found with phone number ${phone}.`
      });
    }
    return res.render('find-results', { title: 'Customer Search Results', customer });
  } catch (error) {
    return next(error);
  }
});

app.get('/update-status', requireUser('staff'), async (req, res, next) => {
  const orderId = typeof req.query.orderId === 'string' ? req.query.orderId.trim() : '';
  if (!orderId) {
    return res.status(400).render('message', {
      title: 'Update Order Status',
      message: 'Missing order ID. Return to the Dashboard and choose an order.'
    });
  }

  try {
    const order = await business.getOrderDetails(orderId);
    if (!order) {
      return res.status(404).render('message', {
        title: 'Update Order Status',
        message: 'Order not found. Return to the Dashboard.'
      });
    }
    return res.render('update-status', { title: 'Update Order Status', order });
  } catch (error) {
    return next(error);
  }
});

app.post('/update-status', requireUser('staff'), async (req, res, next) => {
  const orderId = typeof req.body.orderId === 'string' ? req.body.orderId.trim() : '';
  const newStatus = typeof req.body.status === 'string' ? req.body.status : '';
  if (!orderId || !newStatus) return res.status(400).send('Invalid State');

  try {
    const updated = await business.updateOrderStatus(orderId, newStatus);
    if (!updated) return res.status(400).send('Invalid State');
    return res.redirect('/staff-dashboard');
  } catch (error) {
    return next(error);
  }
});

app.use((req, res) => {
  res.status(404).render('message', {
    title: 'Page Not Found',
    message: 'Page not found. Use the navigation menu to continue.'
  });
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  const generic = 'The request could not be completed.';
  const message = process.env.NODE_ENV === 'production' ? generic : `${generic} Details: ${error.message}`;
  // If even the error page cannot be rendered (e.g. a broken template), fall back to plain text.
  return res.status(500).render('message', { title: 'Error', message }, (renderError, html) => {
    if (renderError) {
      console.error(renderError);
      return res.type('text/plain').send(`${message}\n(The error page itself failed: ${renderError.message})`);
    }
    return res.send(html);
  });
});

/**
 * Starts the web server after confirming the database can be reached, and
 * prints a clear message for the two most common start-up problems.
 * @returns {Promise<void>}
 */
async function start() {
  try {
    await business.checkConnection();
  } catch (error) {
    console.error(`Could not connect to MongoDB: ${error.message}`);
    console.error('Check MONGODB_URI in .env (username, password) and that your IP address is allowed in Atlas > Network Access.');
    process.exit(1);
  }

  const server = app.listen(port, () => {
    console.log(`Laundry Order Management System listening on http://127.0.0.1:${port}`);
  });
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use: another copy of the app is still running. Stop it (Ctrl+C in its terminal, or run: lsof -i :${port} then kill <PID>) and start again.`);
    } else {
      console.error(error);
    }
    process.exit(1);
  });
}

start();
