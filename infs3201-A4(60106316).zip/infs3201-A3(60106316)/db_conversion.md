
## Prompts submitted

> Note: I attached my Assignment 3 project (zip) and the Assignment 4 PDF with this prompt.

### Prompt 1

```
You are an expert full-stack web developer and teaching assistant helping me complete Assignment 4 for INFS3201 (Web Technologies II).

Here is my working Assignment 3 code foundation (app.js, business.js, persistence.js, views, and public/css/styles.css). Please review and retain this exact codebase, architecture (closed 3-tier: Presentation -> Business -> Persistence), and styling.

Your task is to refactor and extend this application for Assignment 4, strictly following these requirements from the official assignment description:

---
### ASSIGNMENT 4 REQUIREMENTS:

1. PART 1: Find Customer Update
   - Update the customer search form and route so staff can search for a customer using their PHONE NUMBER instead of a customer ID (e.g., searching by customer_number / phone).

2. PART 2: Database Identifiers and Refactoring & db_transform.js
   - Remove legacy custom string IDs ("customerId", "serviceId", "orderId") from database documents and application logic, transitioning fully to native MongoDB `_id`s.
   - Write a one-time migration utility script called `db_transform.js` that updates existing documents in MongoDB (ensuring orders reference customer `_id`s).
   - Create a file called `db_conversion.md` listing the LLM system used and the prompts submitted.
   - Refactor app code to query and update using native `_id`.

3. PART 3: User Accounts, Sessions, and users.md
   - Add plain text password fields to customer records.
   - Create a new MongoDB collection called `staff_users` containing shop employee email addresses and passwords.
   - Create a document called `users.md` listing test emails and passwords, explicitly indicating who are customers and who are staff.
   - Implement custom session management stored in MongoDB. DO NOT use `express-session`. Use custom session middleware based on course slides/labs, initialized with a fixed 10-minute expiry window.
   - Build a login screen that authenticates credentials against both collections, starts a session, and redirects to a temporary page showing the user type ("staff" or "customer").

4. PART 4: Customer Users & Dashboard
   - When a customer logs in, redirect them to a Customer Dashboard showing only their own orders.
   - Update the navigation layout for customers to display ONLY: "Services", "Dashboard", and "Logout".

5. PART 5: Staff Users & Authorization
   - When a staff user logs in, direct them to a Staff Dashboard showing all current orders with full status update capabilities.
   - Update the staff navigation menu to display: "Services", "Dashboard", "Search Customers", and "Logout".
   - Implement strict route protection/authorization middleware ensuring staff-only routes cannot be accessed by customers or unauthenticated users.

6. PART 6: Sliding Session Window
   - Modify the fixed 10-minute session expiry into a sliding window, extending the session expiration time by 10 minutes on each active user request.

---
### CODING RULES & CONSTRAINTS:
- Strictly maintain the closed 3-tier architecture: Presentation layer routes never talk directly to persistence; all logic goes through business.js.
- NO client-side JavaScript.
- NO `express-session` package. Sessions must be custom-built and stored in MongoDB.
- Ensure all file modifications are complete, production-ready, and error-free.

Please provide the updated code files step-by-step or in full, including `db_transform.js`, `db_conversion.md`, and `users.md`, exactly as requested.
```

### Follow-up prompts

> Note: I attached my Assignment 3 specification (docx) with this prompt.

#### Follow-up prompt 1

```
Before we start Assignment 4, I want you to thoroughly audit my current Assignment 3 code solution that I am providing below.

Check it against standard INFS3201 Assignment 3 requirements:
1. Strictly closed 3-tier architecture (Presentation never talks directly to persistence; all logic passes through business.js).
2. Proper Express static middleware and CSS linking.
3. Correct routing for services, customer search, and orders.
4. Proper MongoDB Compass index optimization compliance.

If there are any mistakes, structural violations, or bugs in my A3 code, fix them right now and explicitly tell me what was fixed and why.

Once my A3 solution is verified and cleaned up, use it as the solid foundation to build and implement Assignment 4, following every single requirement below with absolute precision and zero mistakes:

(The same ASSIGNMENT 4 REQUIREMENTS and CODING RULES & CONSTRAINTS as in Prompt 1 were repeated here.)
