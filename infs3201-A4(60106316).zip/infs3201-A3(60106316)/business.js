import crypto from 'node:crypto';
import * as persistence from './persistence.js';

export const ORDER_STATUSES = ['Received', 'Washing', 'Ready', 'Delivered'];

/** Length of a session. With the sliding window it is renewed on every request. */
export const SESSION_MINUTES = 10;
const SESSION_DURATION_MS = SESSION_MINUTES * 60 * 1000;

/**
 * Checks that a value is a non-empty string.
 * @param {*} value value to check
 * @returns {boolean} true if it is a usable identifier string
 */
function validId(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/**
 * Rounds a number to two decimal places.
 * @param {number} value number to round
 * @returns {number} rounded number
 */
function money(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * Turns whatever the user typed into the stored phone format (XXXX-XXXX).
 * Eight digits typed with or without a dash/space are accepted.
 * @param {string} phone the text typed by the user
 * @returns {string} the phone number to search for
 */
function normalizePhone(phone) {
  const trimmed = phone.trim();
  const digits = trimmed.replace(/\D/g, '');
  if (digits.length === 8 && /^[\d\s-]+$/.test(trimmed)) {
    return `${digits.slice(0, 4)}-${digits.slice(4)}`;
  }
  return trimmed;
}

/**
 * Builds a single printable address from the customer's address parts.
 * @param {object} customer customer document
 * @returns {string} address text
 */
function formatAddress(customer) {
  if (customer.address) return String(customer.address);
  const parts = [];
  if (customer.building) parts.push(`Building ${customer.building}`);
  if (customer.street) parts.push(`Street ${customer.street}`);
  if (customer.zone) parts.push(`Zone ${customer.zone}`);
  if (customer.area) parts.push(customer.area);
  return parts.join(', ');
}

/**
 * Calculates the total price of an order from its items.
 * @param {object} order order document
 * @param {Map<string, object>} serviceMap services keyed by _id string
 * @returns {number} order total
 */
function calculateOrderTotal(order, serviceMap) {
  let total = 0;
  if (Array.isArray(order.items)) {
    for (const item of order.items) {
      const service = serviceMap.get(String(item.serviceId));
      const quantity = Number(item.quantity);
      if (service && Number.isFinite(quantity)) {
        total += Number(service.price) * quantity;
      }
    }
  }
  return money(total);
}

/**
 * Loads only the services used by the given orders, as a lookup table.
 * @param {object[]} orders order documents
 * @returns {Promise<Map<string, object>>} services keyed by _id string
 */
async function loadServiceMap(orders) {
  const ids = new Set();
  for (const order of orders) {
    for (const item of Array.isArray(order.items) ? order.items : []) ids.add(String(item.serviceId));
  }
  const services = await persistence.getServicesByIds([...ids]);
  return new Map(services.map((service) => [String(service._id), service]));
}

/**
 * Converts an order document into the object shown by the views.
 * @param {object} order order document
 * @param {Map<string, object>} serviceMap services keyed by _id string
 * @param {string} customerName name to display for the customer
 * @returns {object} order view model
 */
function toOrderView(order, serviceMap, customerName) {
  return {
    _id: String(order._id),
    customerId: String(order.customerId),
    customerName,
    orderDate: order.orderDate,
    status: order.status,
    displayTotal: calculateOrderTotal(order, serviceMap)
  };
}

/**
 * Checks that the database is reachable (used when the application starts).
 * @returns {Promise<void>} rejects if the database cannot be reached
 */
export async function checkConnection() {
  await persistence.checkConnection();
}

/**
 * Gets the list of services.
 * @returns {Promise<object[]>} services (with _id converted to a string)
 */
export async function getServices() {
  const services = await persistence.getServices();
  return services.map((service) => ({ ...service, _id: String(service._id) }));
}

/**
 * Finds a customer by phone number and attaches their orders.
 * @param {string} phone phone number typed by the staff member
 * @returns {Promise<object|null>} customer with an orders array, or null if not found
 */
export async function getCustomerInformationByPhone(phone) {
  if (!validId(phone)) return null;
  const customer = await persistence.getCustomerByPhone(normalizePhone(phone));
  if (!customer) return null;

  const orders = await persistence.getCustomerOrders(String(customer._id));
  const serviceMap = await loadServiceMap(orders);
  return {
    _id: String(customer._id),
    name: customer.name,
    phone: customer.phone,
    email: customer.email,
    address: formatAddress(customer),
    orders: orders.map((order) => toOrderView(order, serviceMap, customer.name))
  };
}

/**
 * Gets the orders of one customer (customer dashboard).
 * @param {string} customerId the customer's _id as a string
 * @returns {Promise<object[]>} order view models
 */
export async function getOrdersForCustomer(customerId) {
  if (!validId(customerId)) return [];
  const customer = await persistence.getCustomerById(customerId.trim());
  if (!customer) return [];
  const orders = await persistence.getCustomerOrders(String(customer._id));
  const serviceMap = await loadServiceMap(orders);
  return orders.map((order) => toOrderView(order, serviceMap, customer.name));
}

/**
 * Gets every order with the customer's name (staff dashboard).
 * @returns {Promise<object[]>} order view models
 */
export async function getOrders() {
  const orders = await persistence.getOrders();
  const [customers, serviceMap] = await Promise.all([
    persistence.getCustomersByIds([...new Set(orders.map((order) => String(order.customerId)))]),
    loadServiceMap(orders)
  ]);
  const names = new Map(customers.map((customer) => [String(customer._id), customer.name]));
  return orders.map((order) => toOrderView(order, serviceMap, names.get(String(order.customerId)) || 'Unknown customer'));
}

/**
 * Gets one order, plus the dropdown options for the status form. As the
 * assignment requires, the dropdown lists every status, even invalid ones.
 * @param {string} orderId the order's _id as a string
 * @returns {Promise<object|null>} order view model with statusOptions, or null
 */
export async function getOrderDetails(orderId) {
  if (!validId(orderId)) return null;
  const order = await persistence.getOrderDetails(orderId.trim());
  if (!order) return null;

  const [customer, serviceMap] = await Promise.all([
    persistence.getCustomerById(String(order.customerId)),
    loadServiceMap([order])
  ]);
  const view = toOrderView(order, serviceMap, customer ? customer.name : 'Unknown customer');
  view.statusOptions = ORDER_STATUSES.map((status) => ({ value: status, selected: status === order.status }));
  return view;
}

/**
 * Changes the status of an order. Statuses may only move forward
 * (Received -> Washing -> Ready -> Delivered).
 * @param {string} orderId the order's _id as a string
 * @param {string} newStatus the requested status
 * @returns {Promise<boolean>} true if the status was changed
 */
export async function updateOrderStatus(orderId, newStatus) {
  if (!validId(orderId) || typeof newStatus !== 'string') return false;

  const order = await persistence.getOrderDetails(orderId.trim());
  if (!order) return false;

  const currentPosition = ORDER_STATUSES.indexOf(order.status);
  const newPosition = ORDER_STATUSES.indexOf(newStatus);
  if (currentPosition === -1 || newPosition === -1 || newPosition <= currentPosition) {
    return false;
  }

  return persistence.updateOrderStatus(orderId.trim(), newStatus);
}

/**
 * Creates a session for a verified user and stores it.
 * @param {string} userType 'staff' or 'customer'
 * @param {object} user the staff_users or customers document
 * @returns {Promise<{token: string, expiresAt: Date, userType: string}>} the new session details
 */
async function startSession(userType, user) {
  const token = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_MS);
  await persistence.createSession({
    token,
    userType,
    userId: String(user._id),
    email: user.email,
    createdAt: now,
    expiresAt
  });
  return { token, expiresAt, userType };
}

/**
 * Checks an email and password against staff_users first, then customers
 * (emails are stored in lower case), and starts a session when they are valid.
 * @param {string} email email typed on the login form
 * @param {string} password password typed on the login form
 * @returns {Promise<{token: string, expiresAt: Date, userType: string}|null>} the session, or null if the login is invalid
 */
export async function login(email, password) {
  if (typeof email !== 'string' || typeof password !== 'string') return null;
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !password) return null;

  const staff = await persistence.getStaffByEmail(cleanEmail);
  if (staff && staff.password === password) {
    return startSession('staff', staff);
  }

  const customer = await persistence.getCustomerByEmail(cleanEmail);
  if (customer && customer.password === password) {
    return startSession('customer', customer);
  }

  return null;
}

/**
 * Looks up the session for a cookie token. Expired sessions are removed.
 * A valid session is extended by SESSION_MINUTES on every call (sliding window).
 * @param {string} token the session token from the cookie
 * @returns {Promise<{userType: string, userId: string, email: string, expiresAt: Date}|null>} the session, or null if missing/expired
 */
export async function getSession(token) {
  if (typeof token !== 'string' || !/^[0-9a-f]{64}$/.test(token)) return null;
  const session = await persistence.getSession(token);
  if (!session) return null;

  const now = Date.now();
  let expiresAt = new Date(session.expiresAt);
  if (expiresAt.getTime() <= now) {
    await persistence.deleteSession(token);
    return null;
  }

  // PART 6 - sliding window: every request pushes the expiry 10 minutes ahead.
  // (The fixed 10 minute window of Part 3 simply does not have these two lines.)
  expiresAt = new Date(now + SESSION_DURATION_MS);
  await persistence.updateSessionExpiry(token, expiresAt);

  return {
    userType: session.userType,
    userId: String(session.userId),
    email: session.email,
    expiresAt
  };
}

/**
 * Ends a session.
 * @param {string} token the session token
 * @returns {Promise<void>}
 */
export async function logout(token) {
  await persistence.deleteSession(token);
}
