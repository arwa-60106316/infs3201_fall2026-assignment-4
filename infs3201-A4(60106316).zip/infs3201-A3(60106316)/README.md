# Assignment 1
The solution provided for assignment 1 is somewhat sketchy!  This was done on purpose so that there will be a bit more work to be done for the students who use this as a starting point for Assignment 2

# Assignment 2
It should be closer to a good design. We specifically loaded the .env variables at the start of the
application and just used them in the business layer.  To be honest we really wouldn't use a 
.env file for business configuration but might consider a json file instead.  The .env file is excellent for things that would actually change depending on the deployment location such as the port number, the ip address, the URL if it is needed, etc.  We included the .env this time just as a demonstration of what we could use it for.



# INFS3201 - Laundry Order Management System (Assignment 4)

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and set `MONGODB_URI` (and `DB_NAME` / `PORT` if needed).
3. **One-time database maintenance** (take a backup of the database first):
   1. `node db_transform.js --dry-run`  - optional, shows what will change
   2. `node db_transform.js`            - removes the old ids, keeps only `_id` (refuses to run twice)
   3. `node seed_users.js`              - adds customer passwords and creates `staff_users`
4. `npm start`, then open `http://127.0.0.1:8000/login` (accounts are listed in `users.md`).

## Routes

| Route                | Who                | Purpose                                   |
|----------------------|--------------------|-------------------------------------------|
| `/login`, `/logout`  | everyone           | authenticate / end the session            |
| `/services`          | any logged-in user | service list (menu depends on user type)  |
| `/customer-dashboard`| customers          | the customer's own orders                 |
| `/staff-dashboard`   | staff              | all orders, with Update Status links      |
| `/customer`, `/find-results` | staff      | find a customer by phone number           |
| `/update-status`     | staff              | move an order forward in its status       |
| `/session-info`      | any logged-in user | shows user type and when the session ends |

Sessions are custom (no `express-session`): a random token is kept in an HttpOnly cookie and the session
document (token, user type, user `_id`, expiry) lives in the MongoDB `sessions` collection. Each request
extends the session by 10 minutes (sliding window).

## Indexes (created in MongoDB Compass, no code)

Indexes follow the fields the application searches by:

| Collection    | Index                                   | Used for                                        |
|---------------|-----------------------------------------|-------------------------------------------------|
| `customers`   | `{ phone: 1 }`                          | Find Customer by phone number                   |
| `customers`   | `{ email: 1 }`                          | customer login                                  |
| `staff_users` | `{ email: 1 }` (unique)                 | staff login                                     |
| `orders`      | `{ customerId: 1, orderDate: 1 }`       | customer dashboard and customer search results  |
| `sessions`    | `{ token: 1 }` (unique)                 | session lookup on every request                 |
| `sessions`    | `{ expiresAt: 1 }`, expireAfterSeconds `0` (TTL) | MongoDB removes expired sessions       |

`_id` is indexed automatically, so no extra index is needed for orders, customers or services looked up by `_id`.
Emails are stored in lower case; the login lowercases what the user types.
