import { MongoClient, ObjectId } from 'mongodb';

const connectionString = process.env.MONGODB_URI;
const databaseName = process.env.DB_NAME || process.env.MONGODB_DATABASE || 'infs3201_fall2026';

if (!connectionString) {
  throw new Error('MONGODB_URI is not configured. Copy .env.example to .env and set the connection string.');
}

const client = new MongoClient(connectionString);

// Cached connection (the one global the course guidelines allow in this layer).
let databasePromise;

/**
 * Connects to MongoDB once and caches the connection. Indexes are created in
 * MongoDB Compass (see README.md), not in code.
 * @returns {Promise<import('mongodb').Db>} the database handle
 */
async function getDatabase() {
  if (!databasePromise) {
    databasePromise = client.connect()
      .then(() => client.db(databaseName))
      .catch((error) => {
        databasePromise = undefined;
        throw error;
      });
  }
  return databasePromise;
}

/**
 * Checks that the database can be reached.
 * @returns {Promise<void>} resolves when MongoDB answers, rejects with the connection error otherwise
 */
export async function checkConnection() {
  const db = await getDatabase();
  await db.command({ ping: 1 });
}

/**
 * Gets a collection handle by name.
 * @param {string} name collection name
 * @returns {Promise<import('mongodb').Collection>} the collection
 */
async function collection(name) {
  const db = await getDatabase();
  return db.collection(name);
}

/**
 * Converts a 24 character hex string into an ObjectId.
 * @param {*} value candidate identifier
 * @returns {ObjectId|null} the ObjectId, or null when the value is not a valid id
 */
function toObjectId(value) {
  if (value instanceof ObjectId) return value;
  if (typeof value !== 'string' || !/^[0-9a-fA-F]{24}$/.test(value.trim())) return null;
  return new ObjectId(value.trim());
}

/**
 * Gets every service, in the order they were created.
 * @returns {Promise<object[]>} service documents
 */
export async function getServices() {
  const services = await collection('services');
  return services.find({}).sort({ _id: 1 }).toArray();
}

/**
 * Gets the services whose _id is in the given list.
 * @param {string[]} serviceIds hex strings of service _id values
 * @returns {Promise<object[]>} service documents
 */
export async function getServicesByIds(serviceIds) {
  const ids = serviceIds.map(toObjectId).filter((id) => id !== null);
  if (ids.length === 0) return [];
  const services = await collection('services');
  return services.find({ _id: { $in: ids } }).toArray();
}

/**
 * Gets the customers whose _id is in the given list.
 * @param {string[]} customerIds hex strings of customer _id values
 * @returns {Promise<object[]>} customer documents
 */
export async function getCustomersByIds(customerIds) {
  const ids = customerIds.map(toObjectId).filter((id) => id !== null);
  if (ids.length === 0) return [];
  const customers = await collection('customers');
  return customers.find({ _id: { $in: ids } }).toArray();
}

/**
 * Finds a customer by _id.
 * @param {string} customerId hex string of the customer _id
 * @returns {Promise<object|null>} the customer, or null if not found / invalid id
 */
export async function getCustomerById(customerId) {
  const id = toObjectId(customerId);
  if (!id) return null;
  const customers = await collection('customers');
  return customers.findOne({ _id: id });
}

/**
 * Finds a customer by exact phone number.
 * @param {string} phone phone number as stored (e.g. 5512-4837)
 * @returns {Promise<object|null>} the customer, or null if not found
 */
export async function getCustomerByPhone(phone) {
  if (typeof phone !== 'string' || !phone) return null;
  const customers = await collection('customers');
  return customers.findOne({ phone });
}

/**
 * Finds a customer by email address (emails are stored in lower case).
 * @param {string} email lower case email address
 * @returns {Promise<object|null>} the customer, or null if not found
 */
export async function getCustomerByEmail(email) {
  if (typeof email !== 'string' || !email) return null;
  const customers = await collection('customers');
  return customers.findOne({ email });
}

/**
 * Finds a staff user by email address (emails are stored in lower case).
 * @param {string} email lower case email address
 * @returns {Promise<object|null>} the staff user, or null if not found
 */
export async function getStaffByEmail(email) {
  if (typeof email !== 'string' || !email) return null;
  const staff = await collection('staff_users');
  return staff.findOne({ email });
}

/**
 * Gets every order, oldest first.
 * @returns {Promise<object[]>} order documents
 */
export async function getOrders() {
  const orders = await collection('orders');
  return orders.find({}).sort({ orderDate: 1, _id: 1 }).toArray();
}

/**
 * Gets all orders that belong to one customer, oldest first.
 * @param {string} customerId hex string of the customer _id
 * @returns {Promise<object[]>} order documents
 */
export async function getCustomerOrders(customerId) {
  const id = toObjectId(customerId);
  if (!id) return [];
  const orders = await collection('orders');
  return orders.find({ customerId: id }).sort({ orderDate: 1, _id: 1 }).toArray();
}

/**
 * Finds one order by _id.
 * @param {string} orderId hex string of the order _id
 * @returns {Promise<object|null>} the order, or null if not found / invalid id
 */
export async function getOrderDetails(orderId) {
  const id = toObjectId(orderId);
  if (!id) return null;
  const orders = await collection('orders');
  return orders.findOne({ _id: id });
}

/**
 * Sets the status of one order.
 * @param {string} orderId hex string of the order _id
 * @param {string} newStatus the new status text
 * @returns {Promise<boolean>} true if an order was updated
 */
export async function updateOrderStatus(orderId, newStatus) {
  const id = toObjectId(orderId);
  if (!id) return false;
  const orders = await collection('orders');
  const result = await orders.updateOne({ _id: id }, { $set: { status: newStatus } });
  return result.matchedCount === 1;
}

/**
 * Inserts a new order.
 * @param {object} orderDetails the order fields (customerId must be an ObjectId)
 * @returns {Promise<object>} the stored order including its new _id
 */
export async function createOrder(orderDetails) {
  const orders = await collection('orders');
  const result = await orders.insertOne({ ...orderDetails });
  return { ...orderDetails, _id: result.insertedId };
}

/**
 * Stores a new session.
 * @param {{token: string, userType: string, userId: string, email: string, createdAt: Date, expiresAt: Date}} session the session
 * @returns {Promise<void>}
 */
export async function createSession(session) {
  const sessions = await collection('sessions');
  await sessions.insertOne({ ...session, userId: toObjectId(session.userId) });
}

/**
 * Finds a session by its token.
 * @param {string} token the session token from the cookie
 * @returns {Promise<object|null>} the session document, or null
 */
export async function getSession(token) {
  if (typeof token !== 'string' || !token) return null;
  const sessions = await collection('sessions');
  return sessions.findOne({ token });
}

/**
 * Changes the expiry date of a session.
 * @param {string} token the session token
 * @param {Date} expiresAt the new expiry date
 * @returns {Promise<boolean>} true if the session existed
 */
export async function updateSessionExpiry(token, expiresAt) {
  const sessions = await collection('sessions');
  const result = await sessions.updateOne({ token }, { $set: { expiresAt } });
  return result.matchedCount === 1;
}

/**
 * Deletes a session.
 * @param {string} token the session token
 * @returns {Promise<void>}
 */
export async function deleteSession(token) {
  if (typeof token !== 'string' || !token) return;
  const sessions = await collection('sessions');
  await sessions.deleteOne({ token });
}
